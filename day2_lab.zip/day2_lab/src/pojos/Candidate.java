package pojos;

public class Candidate {
int id,votes;
String name,political_party;
public Candidate(int id, String name, String political_party, int votes) {
	super();
	this.id = id;
	this.votes = votes;
	this.name = name;
	this.political_party = political_party;
}
@Override
public String toString() {
	return "Candidate [id=" + id + ", votes=" + votes + ", name=" + name + ", political_party=" + political_party + "]";
}
public int getId() {
	return id;
}
public int getVotes() {
	return votes;
}
public String getName() {
	return name;
}
public String getPolitical_party() {
	return political_party;
}


}