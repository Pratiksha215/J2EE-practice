package com.app.pojos;

public enum PersonRole {
     ProjectManager,
     Developer,
     TestEngineer;
}
