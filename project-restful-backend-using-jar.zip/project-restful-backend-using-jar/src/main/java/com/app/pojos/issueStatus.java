package com.app.pojos;

public enum issueStatus {
	Active,
	InProgress,
	OnTrack,
	Delayed,
	InTesting,
	OnHold,
	Approved,
	Cancelled,
	Planning,
	Completed,
	Invoiced
}
