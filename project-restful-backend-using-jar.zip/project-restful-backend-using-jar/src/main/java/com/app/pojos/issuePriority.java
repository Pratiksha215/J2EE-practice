package com.app.pojos;

public enum issuePriority {
	 Blocker, Critical, Major, Minor, Trivial
}
